package com.example.demo.dto;

import com.example.demo.domain.Application;
import com.example.demo.domain.Employee;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeApplicationDTO {

    private Long employeeAppId;
    private Employee employee;
    private Application application;
    private String allocation;
    private Date startDate;
    private Date endDate;
}
