package com.example.demo.service.impl;

import com.example.demo.domain.Employee;
import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dtomapper.EmployeeDTOMapper;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService, UserDetailsService {

    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmployeeDTOMapper employeeDTOMapper;

    // Constructor manual pentru inițializarea câmpurilor
    public EmployeeServiceImpl(EmployeeRepository employeeRepository,
                               PasswordEncoder passwordEncoder,
                               EmployeeDTOMapper employeeDTOMapper) {
        this.employeeRepository = employeeRepository;
        this.passwordEncoder = passwordEncoder;
        this.employeeDTOMapper = employeeDTOMapper;
    }

    @Override
    public List<EmployeeDTO> getAllEmployees() {
        return employeeRepository.findAll().stream()
                .map(employeeDTOMapper::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public EmployeeDTO getEmployeeById(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EntityNotFoundException("Employee not found with id: " + employeeId));

        return employeeDTOMapper.convertToDTO(employee);
    }

    @Override
    public EmployeeDTO createEmployee(Employee employee) {
        return employeeDTOMapper.convertToDTO(employeeRepository.save(employee));
    }

    @Override
    public EmployeeDTO updateEmployee(Employee employee) {
        return employeeDTOMapper.convertToDTO(employeeRepository.save(employee));
    }

    @Override
    public Employee findByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    @Override
    public void deleteEmployee(Long employeeId) {
        Employee existingEmployee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EntityNotFoundException("Employee not found with id: " + employeeId));
        employeeRepository.delete(existingEmployee);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Employee employeeEntity = employeeRepository.findByEmail(email);

        if (employeeEntity == null) {
            throw new UsernameNotFoundException("User not found with username: " + email);
        }

        return User.builder()
                .username(employeeEntity.getEmail())
                .password(passwordEncoder.encode(employeeEntity.getPassword()))
                .roles("USER")
                .build();
    }
}

