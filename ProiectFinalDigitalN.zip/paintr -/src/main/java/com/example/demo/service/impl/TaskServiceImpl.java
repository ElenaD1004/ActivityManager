package com.example.demo.service.impl;

import com.example.demo.domain.Task;
import com.example.demo.dto.TaskDTO;
import com.example.demo.dtomapper.TaskDTOMapper;
import com.example.demo.repository.TaskRepository;
import com.example.demo.service.TaskService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final TaskDTOMapper taskDTOMapper;

    // Constructor manual pentru inițializarea câmpurilor
    public TaskServiceImpl(TaskRepository taskRepository, TaskDTOMapper taskDTOMapper) {
        this.taskRepository = taskRepository;
        this.taskDTOMapper = taskDTOMapper;
    }

    @Override
    public List<TaskDTO> getAllTasks() {
        return taskRepository.findAll().stream()
                .map(taskDTOMapper::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public TaskDTO createTask(Task task) {
        return taskDTOMapper.convertToDTO(taskRepository.save(task));
    }

    @Override
    public List<Task> getTasksForEmployee(String userEmail) {
        return taskRepository.findByAssignedEmployeeEmail(userEmail);
    }

    @Override
    public TaskDTO getTaskById(Long taskId) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found with id: " + taskId));

        return taskDTOMapper.convertToDTO(task);
    }

    @Override
    public TaskDTO updateTask(Task task) {
        return taskDTOMapper.convertToDTO(taskRepository.save(task));
    }

    @Override
    public void deleteTask(Long taskId) {
        Task existingTask = taskRepository.findById(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found with id: " + taskId));

        taskRepository.delete(existingTask);
    }
}

