package com.example.demo.service.impl;

import com.example.demo.domain.TimerState;
import com.example.demo.dto.TaskDTO;
import com.example.demo.dtomapper.TaskDTOMapper;
import com.example.demo.service.TaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Service
public class TaskTimerService {

    private static final Logger log = LoggerFactory.getLogger(TaskTimerService.class);

    private final Map<Long, TimerState> timers = new HashMap<>();
    private final Map<Long, Map<LocalDate, Integer>> dailyWorkHours = new HashMap<>();
    private final TaskService taskService;
    private final TaskDTOMapper taskDTOMapper;

    public TaskTimerService(TaskService taskService, TaskDTOMapper taskDTOMapper) {
        this.taskService = taskService;
        this.taskDTOMapper = taskDTOMapper;
    }

    public TimerState startOrResumeTimer(Long taskId) {
        TaskDTO task = taskService.getTaskById(taskId);

        int durationInSeconds = task.getDurationInSeconds();
        long startTime = System.currentTimeMillis();

        if (!canWorkMore(taskId, durationInSeconds)) {
            throw new RuntimeException("Employee has reached the daily work limit for this task.");
        }

        TimerState timerState = timers.get(taskId);

        if (timerState == null) {
            timerState = new TimerState(startTime, durationInSeconds);
            timers.put(taskId, timerState);
        } else {
            timerState.resume();
            int remainingTime = task.getDurationInSeconds();
            timerState = new TimerState(startTime, remainingTime);
            timers.put(taskId, timerState);
        }

        task.setDurationInSeconds(timerState.getDurationInSeconds());
        taskService.updateTask(taskDTOMapper.convertToEntity(task));
        return timerState;
    }

    public TimerState pauseTimer(Long taskId) {
        TimerState timerState;
        TaskDTO task = taskService.getTaskById(taskId);

        int remainingTimer = getRemainingTime(taskId);
        log.info("Remaining time: {}", remainingTimer);
        timerState = new TimerState(System.currentTimeMillis(), remainingTimer);
        timers.put(taskId, timerState);

        if (timerState != null) {
            timerState.pause();
        }

        task.setDurationInSeconds(timerState.getDurationInSeconds());
        taskService.updateTask(taskDTOMapper.convertToEntity(task));
        return timerState;
    }

    public void stopTimer(Long taskId) {
        timers.remove(taskId);
    }

    public int getRemainingTime(Long taskId) {
        TimerState timerState = timers.get(taskId);
        TaskDTO task = taskService.getTaskById(taskId);

        return timerState != null ? timerState.calculateRemainingTime() : task.getDurationInSeconds();
    }

    public boolean canWorkMore(Long taskId, int durationInSeconds) {
        LocalDate today = LocalDate.now();
        dailyWorkHours.putIfAbsent(taskId, new HashMap<>());
        Map<LocalDate, Integer> taskWorkHours = dailyWorkHours.get(taskId);
        int totalWorkHoursToday = taskWorkHours.getOrDefault(today, 0);
        return totalWorkHoursToday + (durationInSeconds / 3600) <= 8;
    }

    public void recordWorkHours(Long taskId, int durationInSeconds) {
        LocalDate today = LocalDate.now();
        dailyWorkHours.putIfAbsent(taskId, new HashMap<>());
        Map<LocalDate, Integer> taskWorkHours = dailyWorkHours.get(taskId);
        taskWorkHours.put(today, taskWorkHours.getOrDefault(today, 0) + (durationInSeconds / 3600));
    }
}


