package com.example.demo.controller;

import com.example.demo.domain.Application;
import com.example.demo.domain.HttpResponse;
import com.example.demo.dto.ApplicationDTO;
import com.example.demo.service.impl.ApplicationServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static java.time.LocalTime.now;

@RestController
@AllArgsConstructor
public class ApplicationController {

    private ApplicationServiceImpl applicationService;


    @GetMapping(value="/applications")
    public ResponseEntity<HttpResponse> getAllApplications(){

        List<ApplicationDTO> applicationDTO = applicationService.getAllApplications();

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("application", applicationDTO))
                        .message("Applications retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @GetMapping(value="/application/{applicationId}")
    public ResponseEntity<HttpResponse> getApplicationById(@PathVariable Long applicationId){

        ApplicationDTO applicationDTO = applicationService.getApplicationById(applicationId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("application", applicationDTO))
                        .message("Application retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @PostMapping(value="/application/create")
    public ResponseEntity<HttpResponse> createApplication(@RequestBody Application application){
        ApplicationDTO applicationDTO = applicationService.createApplication(application);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("application", applicationDTO))
                        .message("Application created successfully")
                        .status(HttpStatus.CREATED)
                        .statusCode(HttpStatus.CREATED.value())
                        .build());
    }

    @PutMapping(value="/application/update")
    public ResponseEntity<HttpResponse> updateApplication(@RequestBody Application application){
        ApplicationDTO applicationDTO = applicationService.updateApplication(application);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("application", applicationDTO))
                        .message("Application updated successfully")
                        .status(HttpStatus.CREATED)
                        .statusCode(HttpStatus.CREATED.value())
                        .build());
    }

    @DeleteMapping("/application/{applicationId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<HttpResponse> deleteApplication(@PathVariable Long applicationId) {
        applicationService.deleteApplication(applicationId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .message("Application deleted successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }
}
