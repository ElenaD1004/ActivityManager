package com.example.demo.dto;

import com.example.demo.domain.Employee;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TaskDTO {
    private Long taskId;
    private String taskName;
    private String taskDetails;
    private int taskAllocatedHours;
    private int actualHoursWorked;
    private LocalDateTime startTime;
    private int durationInSeconds;
    private String status;
    private Employee assignedEmployee;

    // Metodă pentru a obține durata în secunde
    public int getDurationInSeconds() {
        return durationInSeconds;
    }

    // Metodă pentru a seta durata în secunde
    public void setDurationInSeconds(int durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }
}

