package com.example.demo.service;


import com.example.demo.domain.EmployeeApplication;
import com.example.demo.dto.EmployeeApplicationDTO;

import java.util.List;

public interface EmployeeApplicationService {

    List<EmployeeApplicationDTO> getAllEmployeeApplications();

    EmployeeApplicationDTO createEmployeeApplication(EmployeeApplication employeeApplication);

    EmployeeApplicationDTO updateEmployeeApplication(EmployeeApplication employeeApplication);

    void deleteEmployeeApplication(Long employeeApplicationId);

    EmployeeApplicationDTO getEmployeeApplicationById(Long employeeApplicationId);
}
