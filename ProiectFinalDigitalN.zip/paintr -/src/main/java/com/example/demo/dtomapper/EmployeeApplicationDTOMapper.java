package com.example.demo.dtomapper;

import com.example.demo.domain.EmployeeApplication;
import com.example.demo.dto.EmployeeApplicationDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmployeeApplicationDTOMapper {

    @Autowired
    private final ModelMapper modelMapper;

    public EmployeeApplicationDTOMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public EmployeeApplicationDTO convertToDTO(EmployeeApplication employeeApplication) {
        return modelMapper.map(employeeApplication, EmployeeApplicationDTO.class);
    }

    public EmployeeApplication convertToEntity(EmployeeApplicationDTO employeeApplicationDTO) {
        return modelMapper.map(employeeApplicationDTO, EmployeeApplication.class);
    }
}
