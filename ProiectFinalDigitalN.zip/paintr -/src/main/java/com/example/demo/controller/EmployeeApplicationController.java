package com.example.demo.controller;

import com.example.demo.domain.EmployeeApplication;
import com.example.demo.domain.HttpResponse;
import com.example.demo.dto.EmployeeApplicationDTO;
import com.example.demo.service.EmployeeApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static java.time.LocalTime.now;

@RestController
public class EmployeeApplicationController {

    private final EmployeeApplicationService employeeApplicationService;

    // Constructor manual care inițializează câmpul final
    public EmployeeApplicationController(EmployeeApplicationService employeeApplicationService) {
        this.employeeApplicationService = employeeApplicationService;
    }

    @GetMapping(value = "/employee/applications")
    public ResponseEntity<HttpResponse> getAllEmployeeApplications() {
        List<EmployeeApplicationDTO> employeeApplicationDTO = employeeApplicationService.getAllEmployeeApplications();

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employeeApplication", employeeApplicationDTO))
                        .message("Employee applications retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @GetMapping("employee/application/{employeeApplicationId}")
    public ResponseEntity<HttpResponse> getEmployeeApplicationById(@PathVariable Long employeeApplicationId) {
        EmployeeApplicationDTO employeeApplicationDTO = employeeApplicationService.getEmployeeApplicationById(employeeApplicationId);
        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employeeApplication", employeeApplicationDTO))
                        .message("Employee application retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @PostMapping(value = "/employee/application/create")
    public ResponseEntity<HttpResponse> createEmployeeApplication(@RequestBody EmployeeApplication employeeApplication) {
        EmployeeApplicationDTO employeeApplicationDTO = employeeApplicationService.createEmployeeApplication(employeeApplication);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employeeApplication", employeeApplicationDTO))
                        .message("Employee application created successfully")
                        .status(HttpStatus.CREATED)
                        .statusCode(HttpStatus.CREATED.value())
                        .build());
    }

    @PutMapping(value = "/employee/application/update")
    public ResponseEntity<HttpResponse> updateEmployeeApplication(@RequestBody EmployeeApplication employeeApplication) {
        EmployeeApplicationDTO employeeApplicationDTO = employeeApplicationService.updateEmployeeApplication(employeeApplication);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employeeApplication", employeeApplicationDTO))
                        .message("Employee application updated successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @DeleteMapping("/employee/application/{employeeApplicationId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<HttpResponse> deleteEmployeeApplication(@PathVariable Long employeeApplicationId) {
        employeeApplicationService.deleteEmployeeApplication(employeeApplicationId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .message("Employee application deleted successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }
}
