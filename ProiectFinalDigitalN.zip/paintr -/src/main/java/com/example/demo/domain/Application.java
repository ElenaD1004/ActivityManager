package com.example.demo.domain;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "applications")
@Data
public class Application implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_id")
    private Long applicationId;

    @Column(name = "application_name")
    private String applicationName;

    private String applicationCode;

    private String productOwner;

    private String projectManager;

    private Integer developersNumber;

    private Date startDate;
    private Date endDate;

    // Constructor cu un singur parametru pentru applicationName
    public Application(String applicationName) {
        this.applicationName = applicationName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Application that = (Application) o;
        return Objects.equals(applicationId, that.applicationId) && 
               Objects.equals(applicationName, that.applicationName) && 
               Objects.equals(applicationCode, that.applicationCode) && 
               Objects.equals(productOwner, that.productOwner) && 
               Objects.equals(projectManager, that.projectManager) && 
               Objects.equals(developersNumber, that.developersNumber) && 
               Objects.equals(startDate, that.startDate) && 
               Objects.equals(endDate, that.endDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(applicationId, applicationName, applicationCode, 
                            productOwner, projectManager, developersNumber, 
                            startDate, endDate);
    }
}
