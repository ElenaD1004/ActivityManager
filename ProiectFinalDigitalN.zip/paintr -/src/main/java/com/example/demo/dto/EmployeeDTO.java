package com.example.demo.dto;

import com.example.demo.domain.Task;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDTO {

    private String firstName;
    private String lastName;
    private String email;
    private String status;
    private String directSuperior;
    private String contractType;
    private String role;
    private Date startDate;
    private Date endDate;
    private List<Task> assignedTasks = new ArrayList<>();
}
