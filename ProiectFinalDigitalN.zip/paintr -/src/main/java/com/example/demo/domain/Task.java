package com.example.demo.domain;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "tasks")
public class Task implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long taskId;
    private String taskName;
    private String taskDetails;
    private int taskAllocatedHours;
    private int actualHoursWorked;
    private LocalDateTime startTime;
    private int durationInSeconds;
    private String status;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "assigned_employee_id")
    private Employee assignedEmployee;

    // Constructor implicit
    public Task() {
    }

    // Constructor cu toți parametrii necesari
    public Task(Long taskId, String taskName, String taskDetails, int taskAllocatedHours, int actualHoursWorked,
                LocalDateTime startTime, int durationInSeconds, String status, Employee assignedEmployee) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.taskDetails = taskDetails;
        this.taskAllocatedHours = taskAllocatedHours;
        this.actualHoursWorked = actualHoursWorked;
        this.startTime = startTime;
        this.durationInSeconds = durationInSeconds;
        this.status = status;
        this.assignedEmployee = assignedEmployee;
    }

    // Getters și Setters
    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDetails() {
        return taskDetails;
    }

    public void setTaskDetails(String taskDetails) {
        this.taskDetails = taskDetails;
    }

    public int getTaskAllocatedHours() {
        return taskAllocatedHours;
    }

    public void setTaskAllocatedHours(int taskAllocatedHours) {
        this.taskAllocatedHours = taskAllocatedHours;
    }

    public int getActualHoursWorked() {
        return actualHoursWorked;
    }

    public void setActualHoursWorked(int actualHoursWorked) {
        this.actualHoursWorked = actualHoursWorked;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public int getDurationInSeconds() {
        return durationInSeconds;
    }

    public void setDurationInSeconds(int durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Employee getAssignedEmployee() {
        return assignedEmployee;
    }

    public void setAssignedEmployee(Employee assignedEmployee) {
        this.assignedEmployee = assignedEmployee;
    }
}
