package com.example.demo.controller;

import com.example.demo.domain.Employee;
import com.example.demo.domain.HttpResponse;
import com.example.demo.dto.EmployeeDTO;
import com.example.demo.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static java.time.LocalTime.now;

@RestController
@CrossOrigin(value = "http://localhost:4200")
public class EmployeeController {

    private final EmployeeService employeeService;

    // Constructor manual pentru inițializarea câmpului final
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping(value = "/employees")
    public ResponseEntity<HttpResponse> getAllEmployees() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        System.out.println("User " + username + " accessed /employees endpoint");
        List<EmployeeDTO> employeeDTO = employeeService.getAllEmployees();

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employee", employeeDTO))
                        .message("Employees retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @GetMapping(value = "/employee/{employeeId}")
    public ResponseEntity<HttpResponse> getEmployeeById(@PathVariable Long employeeId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        System.out.println("User " + username + " accessed /employee endpoint");
        EmployeeDTO employeeDTO = employeeService.getEmployeeById(employeeId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employee", employeeDTO))
                        .message("Employee retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @PostMapping(value = "/employee/add")
    public ResponseEntity<HttpResponse> createEmployee(@RequestBody Employee employee) {
        EmployeeDTO employeeDTO = employeeService.createEmployee(employee);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employee", employeeDTO))
                        .message("Employee created successfully")
                        .status(HttpStatus.CREATED)
                        .statusCode(HttpStatus.CREATED.value())
                        .build());
    }

    @PutMapping(value = "/employee/update")
    public ResponseEntity<HttpResponse> updateEmployee(@RequestBody Employee employee) {
        EmployeeDTO employeeDTO = employeeService.updateEmployee(employee);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("employee", employeeDTO))
                        .message("Employee updated successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @DeleteMapping(value = "/employee/{employeeId}")
    public ResponseEntity<HttpResponse> deleteEmployee(@PathVariable Long employeeId) {
        employeeService.deleteEmployee(employeeId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .message("Employee deleted successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }
}
