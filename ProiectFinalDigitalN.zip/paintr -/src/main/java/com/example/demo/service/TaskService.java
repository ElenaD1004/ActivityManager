package com.example.demo.service;

import com.example.demo.domain.Task;
import com.example.demo.dto.TaskDTO;

import java.util.List;

public interface TaskService {

    List<TaskDTO> getAllTasks();

    TaskDTO createTask(Task task);

    List<Task> getTasksForEmployee(String userEmail);

//    void startWorkOnTask(Long taskId);
//
//    void stopWorkOnTask(Long taskId);

    TaskDTO getTaskById(Long taskId);

    TaskDTO updateTask(Task task);

    void deleteTask(Long taskId);
}
