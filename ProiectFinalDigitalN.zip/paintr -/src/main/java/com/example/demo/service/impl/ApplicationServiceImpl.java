package com.example.demo.service.impl;

import com.example.demo.domain.Application;
import com.example.demo.dto.ApplicationDTO;
import com.example.demo.dtomapper.ApplicationDTOMapper;
import com.example.demo.repository.ApplicationRepository;
import com.example.demo.service.ApplicationService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationDTOMapper applicationDTOMapper;

    // Constructor manual pentru inițializarea câmpurilor
    public ApplicationServiceImpl(ApplicationRepository applicationRepository, ApplicationDTOMapper applicationDTOMapper) {
        this.applicationRepository = applicationRepository;
        this.applicationDTOMapper = applicationDTOMapper;
    }

    @Override
    public List<ApplicationDTO> getAllApplications() {
        return applicationRepository.findAll().stream()
                .map(applicationDTOMapper::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationDTO createApplication(Application application) {
        return applicationDTOMapper.convertToDTO(applicationRepository.save(application));
    }

    @Override
    public ApplicationDTO updateApplication(Application application) {
        return applicationDTOMapper.convertToDTO(applicationRepository.save(application));
    }

    @Override
    public ApplicationDTO getApplicationById(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + applicationId));

        return applicationDTOMapper.convertToDTO(application);
    }

    @Override
    public void deleteApplication(Long applicationId) {
        Application existingApplication = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + applicationId));
        applicationRepository.delete(existingApplication);
    }
}

