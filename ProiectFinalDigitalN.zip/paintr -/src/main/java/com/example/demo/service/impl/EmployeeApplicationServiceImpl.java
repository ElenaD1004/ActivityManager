package com.example.demo.service.impl;

import com.example.demo.domain.EmployeeApplication;
import com.example.demo.dto.EmployeeApplicationDTO;
import com.example.demo.dtomapper.EmployeeApplicationDTOMapper;
import com.example.demo.repository.EmployeeApplicationRepository;
import com.example.demo.service.EmployeeApplicationService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeApplicationServiceImpl implements EmployeeApplicationService {

    private final EmployeeApplicationRepository employeeApplicationRepository;
    private final EmployeeApplicationDTOMapper employeeApplicationDTOMapper;

    // Constructor manual pentru inițializarea câmpurilor
    public EmployeeApplicationServiceImpl(EmployeeApplicationRepository employeeApplicationRepository,
                                          EmployeeApplicationDTOMapper employeeApplicationDTOMapper) {
        this.employeeApplicationRepository = employeeApplicationRepository;
        this.employeeApplicationDTOMapper = employeeApplicationDTOMapper;
    }

    @Override
    public List<EmployeeApplicationDTO> getAllEmployeeApplications() {
        return employeeApplicationRepository.findAll().stream()
                .map(employeeApplicationDTOMapper::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public EmployeeApplicationDTO getEmployeeApplicationById(Long employeeApplicationId) {
        EmployeeApplication employeeApplication = employeeApplicationRepository.findById(employeeApplicationId)
                .orElseThrow(() -> new EntityNotFoundException("EmployeeApplication not found with id: " + employeeApplicationId));

        return employeeApplicationDTOMapper.convertToDTO(employeeApplication);
    }

    @Override
    public EmployeeApplicationDTO createEmployeeApplication(EmployeeApplication employeeApplication) {
        return employeeApplicationDTOMapper.convertToDTO(employeeApplicationRepository.save(employeeApplication));
    }

    @Override
    public EmployeeApplicationDTO updateEmployeeApplication(EmployeeApplication employeeApplication) {
        return employeeApplicationDTOMapper.convertToDTO(employeeApplicationRepository.save(employeeApplication));
    }

    @Override
    @Transactional
    public void deleteEmployeeApplication(Long employeeApplicationId) {
        EmployeeApplication existingEmployeeApplication = employeeApplicationRepository.findById(employeeApplicationId)
                .orElseThrow(() -> new EntityNotFoundException("EmployeeApplication not found with id: " + employeeApplicationId));

        employeeApplicationRepository.delete(existingEmployeeApplication);
    }
}


