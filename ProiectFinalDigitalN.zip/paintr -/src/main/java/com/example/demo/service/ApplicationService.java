package com.example.demo.service;

import com.example.demo.domain.Application;
import com.example.demo.dto.ApplicationDTO;

import java.util.List;

public interface ApplicationService {

    List<ApplicationDTO> getAllApplications();

    ApplicationDTO createApplication(Application application);

    ApplicationDTO updateApplication(Application application);

    ApplicationDTO getApplicationById(Long applicationId);

    void deleteApplication(Long applicationId);
}
 