package com.example.demo.dtomapper;

import com.example.demo.domain.Application;
import com.example.demo.dto.ApplicationDTO;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class ApplicationDTOMapper {


    private final ModelMapper modelMapper;

    public ApplicationDTOMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ApplicationDTO convertToDTO(Application application) {
        return modelMapper.map(application, ApplicationDTO.class);
    }

    public Application convertToEntity(ApplicationDTO applicationDTO) {
        return modelMapper.map(applicationDTO, Application.class);
    }

}
