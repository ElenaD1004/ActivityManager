package com.example.demo.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.http.HttpStatus;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class HttpResponse {
    protected String timeStamp;
    protected int statusCode;
    protected HttpStatus status;
    protected String error;
    protected String message;
    protected String developerMessage;
    protected Map<?, ?> data;

    // Constructor pentru Builder
    private HttpResponse(HttpResponseBuilder builder) {
        this.timeStamp = builder.timeStamp;
        this.statusCode = builder.statusCode;
        this.status = builder.status;
        this.error = builder.error;
        this.message = builder.message;
        this.developerMessage = builder.developerMessage;
        this.data = builder.data;
    }

    // Getteri pentru toate câmpurile
    public String getTimeStamp() {
        return timeStamp;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getError() {
        return error;
    }

    public String getMessage() {
        return message;
    }

    public String getDeveloperMessage() {
        return developerMessage;
    }

    public Map<?, ?> getData() {
        return data;
    }

    // Metoda builder()
    public static HttpResponseBuilder builder() {
        return new HttpResponseBuilder();
    }

    // Clasa Builder
    public static class HttpResponseBuilder {
        private String timeStamp;
        private int statusCode;
        private HttpStatus status;
        private String error;
        private String message;
        private String developerMessage;
        private Map<?, ?> data;

        public HttpResponseBuilder timeStamp(String timeStamp) {
            this.timeStamp = timeStamp;
            return this;
        }

        public HttpResponseBuilder statusCode(int statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        public HttpResponseBuilder status(HttpStatus status) {
            this.status = status;
            return this;
        }

        public HttpResponseBuilder error(String error) {
            this.error = error;
            return this;
        }

        public HttpResponseBuilder message(String message) {
            this.message = message;
            return this;
        }

        public HttpResponseBuilder developerMessage(String developerMessage) {
            this.developerMessage = developerMessage;
            return this;
        }

        public HttpResponseBuilder data(Map<?, ?> data) {
            this.data = data;
            return this;
        }

        public HttpResponse build() {
            return new HttpResponse(this);
        }
    }
}
