package com.example.demo.domain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TimerState {

    private static final Logger log = LoggerFactory.getLogger(TimerState.class);

    private long startTime;
    private int durationInSeconds;
    private boolean paused;

    public TimerState() {
        // Default constructor for serialization
    }

    public TimerState(int durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }

    public TimerState(long startTime, int durationInSeconds) {
        this.startTime = startTime;
        this.durationInSeconds = durationInSeconds;
        this.paused = false;
    }

    // Getter pentru durationInSeconds
    public int getDurationInSeconds() {
        return durationInSeconds;
    }

    // Setter pentru durationInSeconds
    public void setDurationInSeconds(int durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }

    // Calculate the remaining time based on the elapsed time
    public int calculateRemainingTime() {
        if (!paused) {
            log.info("Calculating the remaining time");
            long currentTime = System.currentTimeMillis();
            int elapsedTimeInSeconds = (int) ((currentTime - startTime) / 1000);
            int remainingTime = durationInSeconds - elapsedTimeInSeconds;
            log.info("Remaining time is: {} ", remainingTime);
            return remainingTime > 0 ? remainingTime : 0;
        } else {
            return durationInSeconds;
        }
    }

    // Pause the timer
    public void pause() {
        log.info("Task paused");
        paused = true;
    }

    // Resume the timer
    public void resume() {
        log.info("Task resumed");
        paused = false;
    }
}
