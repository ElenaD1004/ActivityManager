package com.example.demo.service;

import com.example.demo.domain.Employee;
import com.example.demo.dto.EmployeeDTO;

import java.util.List;

public interface EmployeeService {

    List<EmployeeDTO> getAllEmployees();

    EmployeeDTO createEmployee(Employee employee);

    EmployeeDTO updateEmployee(Employee employee);

    Employee findByEmail(String email);


    void deleteEmployee(Long employeeId);

    EmployeeDTO getEmployeeById(Long employeeId);
}
