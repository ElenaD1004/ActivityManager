package com.example.demo.domain;

import javax.persistence.*;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="employee_applications")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmployeeApplication implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeAppId;

    @OneToOne
    @JoinColumn(name="employee_id")
    private Employee employee;

    @OneToOne
    @JoinColumn(name="application_id")
    private Application application;
    private String allocation;
    private Date startDate;
    private Date endDate;
}
