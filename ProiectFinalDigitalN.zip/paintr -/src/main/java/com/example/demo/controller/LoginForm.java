package com.example.demo.controller;

public class LoginForm {

    private String email;
    private String password;

    // Getter pentru email
    public String getEmail() {
        return email;
    }

    // Setter pentru email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter pentru password
    public String getPassword() {
        return password;
    }

    // Setter pentru password
    public void setPassword(String password) {
        this.password = password;
    }
}
