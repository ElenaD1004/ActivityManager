package com.example.demo.controller;

import com.example.demo.domain.HttpResponse;
import com.example.demo.domain.Task;
import com.example.demo.domain.TimerState;
import com.example.demo.dto.TaskDTO;
import com.example.demo.service.TaskService;
import com.example.demo.service.impl.TaskTimerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static java.time.LocalTime.now;

@RestController
@RequestMapping(value = "/tasks")
@CrossOrigin(origins = "http://localhost:4200")
public class TaskController {

    private final TaskService taskService;
    private final TaskTimerService taskTimerService;

    // Constructor manual pentru inițializarea câmpurilor finale
    public TaskController(TaskService taskService, TaskTimerService taskTimerService) {
        this.taskService = taskService;
        this.taskTimerService = taskTimerService;
    }

    @GetMapping(value = "/tasks")
    public ResponseEntity<HttpResponse> getAllTasks() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        System.out.println("User " + username + " accessed /task endpoint");
        List<TaskDTO> taskDTO = taskService.getAllTasks();

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("task", taskDTO))
                        .message("Tasks retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @GetMapping(value = "/task/{taskId}")
    public ResponseEntity<HttpResponse> getTaskById(@PathVariable Long taskId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        System.out.println("User " + username + " accessed /task endpoint");
        TaskDTO taskDTO = taskService.getTaskById(taskId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("task", taskDTO))
                        .message("Task retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @GetMapping(value = "/assigned")
    public ResponseEntity<HttpResponse> getAssignedTasks() {
        String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();

        List<Task> assignedTasks = taskService.getTasksForEmployee(userEmail);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("task", assignedTasks))
                        .message("Assigned employee on task retrieved successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @PostMapping(value = "/task/add")
    public ResponseEntity<HttpResponse> createTask(@RequestBody Task task) {
        TaskDTO taskDTO = taskService.createTask(task);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("task", taskDTO))
                        .message("Task created successfully")
                        .status(HttpStatus.CREATED)
                        .statusCode(HttpStatus.CREATED.value())
                        .build());
    }

    @PutMapping(value = "/task/update")
    public ResponseEntity<HttpResponse> updateTask(@RequestBody Task task) {
        TaskDTO taskDTO = taskService.updateTask(task);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .data(Map.of("task", taskDTO))
                        .message("Task updated successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @DeleteMapping(value = "/task/{taskId}")
    public ResponseEntity<HttpResponse> deleteEmployee(@PathVariable Long taskId) {
        taskService.deleteTask(taskId);

        return ResponseEntity.ok().body(
                HttpResponse.builder()
                        .timeStamp(now().toString())
                        .message("Task deleted successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
    }

    @PostMapping("/{taskId}/start-timer")
    public ResponseEntity<TimerState> startTimer(@PathVariable Long taskId) {
        TimerState timerState = taskTimerService.startOrResumeTimer(taskId);
        return new ResponseEntity<>(timerState, HttpStatus.OK);
    }

    @PostMapping("/{taskId}/pause-timer")
    public ResponseEntity<TimerState> pauseTimer(@PathVariable Long taskId) {
        TimerState timerState = taskTimerService.pauseTimer(taskId);
        return ResponseEntity.ok(timerState);
    }

    @PostMapping("/{taskId}/stop-timer")
    public ResponseEntity<Void> stopTimer(@PathVariable Long taskId) {
        int remainingTime = taskTimerService.getRemainingTime(taskId);
        taskTimerService.stopTimer(taskId);
        taskTimerService.recordWorkHours(taskId, remainingTime);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{taskId}/remaining-time")
    public ResponseEntity<Integer> getRemainingTime(@PathVariable Long taskId) {
        int remainingTime = taskTimerService.getRemainingTime(taskId);
        return ResponseEntity.ok(remainingTime);
    }
}
