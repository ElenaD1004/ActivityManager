package com.example.demo.domain;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "employees")
public class Employee implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_id")
    private Long employeeId;

    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String status;
    private String directSuperior;
    private String contractType;
    private String role;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date startDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endDate;

    @OneToMany(mappedBy = "assignedEmployee")
    private List<Task> assignedTasks = new ArrayList<>();

    // Constructor implicit
    public Employee() {
    }

    // Constructor complet
    public Employee(String firstName, String lastName, String email, String password,
                    String status, String directSuperior, String contractType, String role,
                    Date startDate, Date endDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.status = status;
        this.directSuperior = directSuperior;
        this.contractType = contractType;
        this.role = role;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Builder manual pentru Employee
    public static EmployeeBuilder builder() {
        return new EmployeeBuilder();
    }

    public static class EmployeeBuilder {
        private String firstName;
        private String lastName;
        private String email;
        private String password;
        private String status;
        private String directSuperior;
        private String contractType;
        private String role;
        private Date startDate;
        private Date endDate;

        public EmployeeBuilder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public EmployeeBuilder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public EmployeeBuilder email(String email) {
            this.email = email;
            return this;
        }

        public EmployeeBuilder password(String password) {
            this.password = password;
            return this;
        }

        public EmployeeBuilder status(String status) {
            this.status = status;
            return this;
        }

        public EmployeeBuilder directSuperior(String directSuperior) {
            this.directSuperior = directSuperior;
            return this;
        }

        public EmployeeBuilder contractType(String contractType) {
            this.contractType = contractType;
            return this;
        }

        public EmployeeBuilder role(String role) {
            this.role = role;
            return this;
        }

        public EmployeeBuilder startDate(Date startDate) {
            this.startDate = startDate;
            return this;
        }

        public EmployeeBuilder endDate(Date endDate) {
            this.endDate = endDate;
            return this;
        }

        public Employee build() {
            return new Employee(firstName, lastName, email, password, status, directSuperior, contractType, role, startDate, endDate);
        }
    }

    // Getteri
    public Long getEmployeeId() {
        return employeeId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getStatus() {
        return status;
    }

    public String getDirectSuperior() {
        return directSuperior;
    }

    public String getContractType() {
        return contractType;
    }

    public String getRole() {
        return role;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public List<Task> getAssignedTasks() {
        return assignedTasks;
    }

    // Setteri
    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDirectSuperior(String directSuperior) {
        this.directSuperior = directSuperior;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void setAssignedTasks(List<Task> assignedTasks) {
        this.assignedTasks = assignedTasks;
    }
}
