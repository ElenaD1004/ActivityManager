package com.example.demo.controller;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginControllerTest {

    @Test
    public void testLoginFormGettersAndSetters() {
        // Create an instance of LoginForm
        LoginForm loginForm = new LoginForm();

        // Set values using setters
        loginForm.setEmail("test@example.com");
        loginForm.setPassword("password123");

        // Verify values using getters
        assertEquals("test@example.com", loginForm.getEmail());
        assertEquals("password123", loginForm.getPassword());
    }

}


