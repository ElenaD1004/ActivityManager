package com.example.demo.controller;

import com.example.demo.domain.Task;
import com.example.demo.dto.TaskDTO;
import com.example.demo.service.TaskService;
import com.example.demo.service.impl.TaskTimerService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(TaskController.class)
public class TaskControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
    private TaskController taskController;

    @Mock
    private TaskService taskService;

    @Mock
    private TaskTimerService taskTimerService;

    public TaskControllerTest(MockMvc mockMvc) {
        this.mockMvc = mockMvc;
    }

    @Test
    public void getAllTasks() throws Exception {
        // Set up authentication
        authenticateUser("testUser");

        // Mock the service response
        doReturn(Collections.singletonList(new TaskDTO())).when(taskService).getAllTasks();

        // Perform the GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/tasks/tasks"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.task").isArray())
                .andExpect(jsonPath("$.message").value("Tasks retrieved successfully"));
    }

    @Test
    public void getTaskById() throws Exception {
        // Set up authentication
        authenticateUser("testUser");

        // Mock the service response
        doReturn(new TaskDTO()).when(taskService).getTaskById(any());

        // Perform the GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/tasks/task/{taskId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.task").exists())
                .andExpect(jsonPath("$.message").value("Task retrieved successfully"));
    }

    @Test
    public void getAssignedTasks() throws Exception {
        // Set up authentication
        authenticateUser("testUser");

        // Mock the service response
        doReturn(Collections.singletonList(new Task())).when(taskService).getTasksForEmployee("testUser");

        // Perform the GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/tasks/assigned"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.task").isArray())
                .andExpect(jsonPath("$.message").value("Assigned employee on task retrieved successfully"));
    }

    // Add more test cases as needed

    private void authenticateUser(String username) {
        Authentication auth = new UsernamePasswordAuthenticationToken(username, "password");
        SecurityContext securityContext = SecurityContextHolder.getContext();
        securityContext.setAuthentication(auth);
    }

    public TaskController getTaskController() {
        return taskController;
    }

    public void setTaskController(TaskController taskController) {
        this.taskController = taskController;
    }
}


