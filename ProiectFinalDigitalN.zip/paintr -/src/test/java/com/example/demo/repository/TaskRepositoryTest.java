package com.example.demo.repository;

import com.example.demo.domain.Employee;
import com.example.demo.domain.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@Transactional
public class TaskRepositoryTest {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public TaskRepositoryTest(TaskRepository taskRepository, EmployeeRepository employeeRepository) {
        this.taskRepository = taskRepository;
        this.employeeRepository = employeeRepository;
    }

    @Test
    public void testFindByTaskName() {

        Employee employee = Employee.builder()
                .firstName("John")
                .lastName("Doe")
                .email("john.doe@example.com")
                .password("password123")
                .status("Active")
                .directSuperior("Manager")
                .contractType("Full-time")
                .role("Developer")
                .startDate(new Date())
                .endDate(new Date())
                .build();

        employeeRepository.save(employee);

        Task task1 = new Task(1L,"Task 1", "Details 1", 5, 0, LocalDateTime.now(), 3600, "IN_PROGRESS", employee);
        Task task2 = new Task(2L,"Task 2", "Details 2", 8, 0, LocalDateTime.now(), 7200, "COMPLETED", employee);

        // Save tasks to the database
        taskRepository.save(task1);
        taskRepository.save(task2);

        List<Task> tasks = taskRepository.findByTaskName("Task 1");

        assertEquals(1, tasks.size());

        assertTrue(tasks.contains(task1));
    }

}