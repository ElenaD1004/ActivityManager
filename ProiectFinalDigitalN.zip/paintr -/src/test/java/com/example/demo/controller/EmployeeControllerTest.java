package com.example.demo.controller;

import com.example.demo.domain.Employee;
import com.example.demo.dto.EmployeeDTO;
import com.example.demo.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployeeService employeeService;

    @Test
    public void getAllEmployees() throws Exception {
        // Mock the service response
        doReturn(Collections.singletonList(new EmployeeDTO())).when(employeeService).getAllEmployees();

        // Perform the GET request
        mockMvc.perform(get("/employees"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employee").isArray())
                .andExpect(jsonPath("$.message").value("Employees retrieved successfully"));
    }

    @Test
    public void getEmployeeById() throws Exception {
        // Mock the service response
        doReturn(new EmployeeDTO()).when(employeeService).getEmployeeById(any());

        // Perform the GET request
        mockMvc.perform(get("/employee/{employeeId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employee").exists())
                .andExpect(jsonPath("$.message").value("Employee retrieved successfully"));
    }

    @Test
    public void createEmployee() throws Exception {
        // Mock the service response
        doReturn(new EmployeeDTO()).when(employeeService).createEmployee(any());

        // Perform the POST request
        mockMvc.perform(post("/employee/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your employee
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employee").exists())
                .andExpect(jsonPath("$.message").value("Employee created successfully"));
    }

    @Test
    public void updateEmployee() throws Exception {
        // Mock the service response
        doReturn(new EmployeeDTO()).when(employeeService).updateEmployee(any());

        // Perform the PUT request
        mockMvc.perform(put("/employee/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your employee
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employee").exists())
                .andExpect(jsonPath("$.message").value("Employee updated successfully"));
    }

    @Test
    public void deleteEmployee() throws Exception {
        // Perform the DELETE request
        mockMvc.perform(delete("/employee/{employeeId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Employee deleted successfully"));
    }
}
