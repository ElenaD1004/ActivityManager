package com.example.demo.repository;

import com.example.demo.domain.Application;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import javax.transaction.Transactional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@Transactional
public class ApplicationRepositoryTest {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Test
    public void testFindByApplicationName() {
        // Crează obiecte Application pentru testare
        Application application1 = new Application("Leave Request");
        Application application2 = new Application("Vacation Request");

        // Salvează obiectele în baza de date
        applicationRepository.save(application1);
        applicationRepository.save(application2);

        // Apelează metoda din repository pentru a căuta aplicațiile după numele lor
        List<Application> applications = applicationRepository.findByApplicationName("Leave Request");

        // Verifică dacă rezultatul este așteptat
        assertEquals(1, applications.size());
        assertTrue(applications.contains(application1));
    }
}
