package com.example.demo.controller;

import com.example.demo.dto.EmployeeApplicationDTO;
import com.example.demo.service.EmployeeApplicationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EmployeeApplicationController.class)

public class EmployeeApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployeeApplicationService employeeApplicationService;

    public EmployeeApplicationControllerTest(MockMvc mockMvc) {
        this.mockMvc = mockMvc;
    }

    @Test
    public void getAllEmployeeApplications() throws Exception {
        // Mock the service response
        doReturn(Collections.singletonList(new EmployeeApplicationDTO())).when(employeeApplicationService).getAllEmployeeApplications();

        // Perform the GET request
        mockMvc.perform(get("/employee/applications"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employeeApplication").isArray())
                .andExpect(jsonPath("$.message").value("Employee applications retrieved successfully"));
    }

    @Test
    public void getEmployeeApplicationById() throws Exception {
        // Mock the service response
        doReturn(new EmployeeApplicationDTO()).when(employeeApplicationService).getEmployeeApplicationById(any());

        // Perform the GET request
        mockMvc.perform(get("/employee/application/{employeeApplicationId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employeeApplication").exists())
                .andExpect(jsonPath("$.message").value("Employee application retrieved successfully"));
    }

    @Test
    public void createEmployeeApplication() throws Exception {
        // Mock the service response
        doReturn(new EmployeeApplicationDTO()).when(employeeApplicationService).createEmployeeApplication(any());

        // Perform the POST request
        mockMvc.perform(post("/employee/application/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your employee application
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employeeApplication").exists())
                .andExpect(jsonPath("$.message").value("Employee application created successfully"));
    }

    @Test
    public void updateEmployeeApplication() throws Exception {
        // Mock the service response
        doReturn(new EmployeeApplicationDTO()).when(employeeApplicationService).updateEmployeeApplication(any());

        // Perform the PUT request
        mockMvc.perform(put("/employee/application/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your employee application
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.employeeApplication").exists())
                .andExpect(jsonPath("$.message").value("Employee application updated successfully"));
    }

    @Test
    public void deleteEmployeeApplication() throws Exception {
        // Perform the DELETE request
        mockMvc.perform(delete("/employee/application/{employeeApplicationId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Employee application deleted successfully"));
    }
}


