package com.example.demo.controller;

import com.example.demo.dto.ApplicationDTO;
import com.example.demo.service.impl.ApplicationServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ApplicationController.class)
public class ApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ApplicationServiceImpl applicationService;

    public ApplicationControllerTest(MockMvc mockMvc) {
        this.mockMvc = mockMvc;
    }

    @Test
    public void getAllApplications() throws Exception {
        // Mock the service response
        doReturn(Collections.singletonList(new ApplicationDTO())).when(applicationService).getAllApplications();

        // Perform the GET request
        mockMvc.perform(get("/applications"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.application").isArray())
                .andExpect(jsonPath("$.message").value("Applications retrieved successfully"));
    }

    @Test
    public void getApplicationById() throws Exception {
        // Mock the service response
        doReturn(new ApplicationDTO()).when(applicationService).getApplicationById(any());

        // Perform the GET request
        mockMvc.perform(get("/application/{applicationId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.application").exists())
                .andExpect(jsonPath("$.message").value("Application retrieved successfully"));
    }

    @Test
    public void createApplication() throws Exception {
        // Mock the service response
        doReturn(new ApplicationDTO()).when(applicationService).createApplication(any());

        // Perform the POST request
        mockMvc.perform(post("/application/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your application
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.application").exists())
                .andExpect(jsonPath("$.message").value("Application created successfully"));
    }

    @Test
    public void updateApplication() throws Exception {
        // Mock the service response
        doReturn(new ApplicationDTO()).when(applicationService).updateApplication(any());

        // Perform the PUT request
        mockMvc.perform(put("/application/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}")) // You should provide a valid JSON payload for your application
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data.application").exists())
                .andExpect(jsonPath("$.message").value("Application updated successfully"));
    }

    @Test
    public void deleteApplication() throws Exception {
        // Perform the DELETE request
        mockMvc.perform(delete("/application/{applicationId}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Application deleted successfully"));
    }
}


