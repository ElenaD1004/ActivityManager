package com.example.demo.repository;

import com.example.demo.domain.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@Transactional
public class EmployeeRepositoryTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void testFindByFirstName() {

        Employee employee1 = new Employee(
                "John", "Doe", "john.doe@example.com", "password123",
                "Active", "Manager", "Full-time", "Developer",
                new Date(), new Date()  // Adăugăm startDate și endDate
        );

        Employee employee2 = new Employee(
                "Jane", "Doe", "jane.doe@example.com", "password456",
                "Active", "Manager", "Full-time", "Developer",
                new Date(), new Date()  // Adăugăm startDate și endDate
        );

        // Save employees to the database
        employeeRepository.save(employee1);
        employeeRepository.save(employee2);

        List<Employee> employees = employeeRepository.findByFirstName("John");

        assertEquals(1, employees.size());
        assertTrue(employees.contains(employee1));
    }
}
